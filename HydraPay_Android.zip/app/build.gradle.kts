plugins {
    id("com.android.application")
}

android {
    namespace = "com.hydrapay.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hydrapay.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 146
        versionName = "1.4.6"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
