# Hydra Authentication — Android

Projeto Android preparado para gerar um APK instalável do Hydra Authentication.

## Gerar pelo Windows

1. Instale o Android Studio com Android SDK / API 35.
2. Extraia esta pasta.
3. Clique com o botão direito em `GERAR_APK.ps1` e execute com PowerShell.
4. Ao terminar, o APK será criado na raiz com o nome `HydraAuthentication.apk`.

Também é possível abrir esta pasta diretamente no Android Studio e usar:
**Build > Build APK(s)**.

## GitHub Actions

O projeto inclui `.github/workflows/build-apk.yml`.
Ao publicar este projeto em um repositório GitHub, o workflow gera `Hydra-Authentication-APK` automaticamente.

## Observação

O conteúdo web do Hydra está empacotado dentro do APK e é carregado em um origin HTTPS interno do WebView para preservar WebCrypto, câmera e as rotas do sistema.
