$ErrorActionPreference = "Stop"

$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Project

$Sdk = $env:ANDROID_HOME
if (-not $Sdk) { $Sdk = $env:ANDROID_SDK_ROOT }
if (-not $Sdk) {
    $DefaultSdk = Join-Path $env:LOCALAPPDATA "Android\Sdk"
    if (Test-Path $DefaultSdk) { $Sdk = $DefaultSdk }
}

if (-not $Sdk -or -not (Test-Path $Sdk)) {
    Write-Host ""
    Write-Host "Android SDK não encontrado." -ForegroundColor Red
    Write-Host "Instale o Android Studio e o Android SDK primeiro."
    Write-Host "Depois execute este arquivo novamente."
    exit 1
}

$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk

$Platform = Join-Path $Sdk "platforms\android-35\android.jar"
if (-not (Test-Path $Platform)) {
    $SdkManager = Get-ChildItem -Path $Sdk -Filter "sdkmanager.bat" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($SdkManager) {
        Write-Host "Instalando Android API 35 e Build Tools..." -ForegroundColor Cyan
        & $SdkManager.FullName "platforms;android-35" "build-tools;35.0.0"
    }
}

if (-not (Test-Path $Platform)) {
    Write-Host "Abra o Android Studio > SDK Manager e instale Android 15 / API 35." -ForegroundColor Yellow
    exit 1
}

$Tools = Join-Path $Project ".tools"
$GradleDir = Join-Path $Tools "gradle-8.9"
$GradleBat = Join-Path $GradleDir "bin\gradle.bat"

if (-not (Test-Path $GradleBat)) {
    New-Item -ItemType Directory -Path $Tools -Force | Out-Null
    $Zip = Join-Path $Tools "gradle-8.9-bin.zip"
    Write-Host "Baixando Gradle 8.9..." -ForegroundColor Cyan
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-8.9-bin.zip" -OutFile $Zip
    Expand-Archive $Zip -DestinationPath $Tools -Force
    Remove-Item $Zip -Force
}

Write-Host "Compilando..." -ForegroundColor Cyan
& $GradleBat --no-daemon assembleDebug

$Built = Join-Path $Project "app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $Built)) {
    throw "O build terminou sem gerar o APK."
}

$Output = Join-Path $Project "HydraAuthentication.apk"
Copy-Item $Built $Output -Force
Write-Host ""
Write-Host "APK gerado:" -ForegroundColor Green
Write-Host $Output
