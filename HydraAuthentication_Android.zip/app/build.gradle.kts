plugins {
    id("com.android.application")
}

android {
    namespace = "com.hydrapay.authentication"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hydrapay.authentication"
        minSdk = 24
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
